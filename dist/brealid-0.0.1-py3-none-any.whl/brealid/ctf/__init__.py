import pwn


remote = pwn.remote
bytes_xor = pwn.xor