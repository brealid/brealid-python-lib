from . import GaloisNumber_2n


# Alias
GF2n = GaloisNumber_2n.GaloisNumber_2n