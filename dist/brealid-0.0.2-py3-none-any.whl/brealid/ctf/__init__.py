import pwn


# Alias
remote = pwn.remote
bytes_xor = pwn.xor